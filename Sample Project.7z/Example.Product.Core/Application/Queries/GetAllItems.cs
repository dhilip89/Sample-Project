﻿namespace Example.Product.Core.Application.Queries
{
    public sealed class GetAllItems : Query
    {
    }
}
