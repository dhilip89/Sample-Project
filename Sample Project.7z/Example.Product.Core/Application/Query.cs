﻿namespace Example.Product.Core.Application
{
    public abstract class Query
    {
    }
}
